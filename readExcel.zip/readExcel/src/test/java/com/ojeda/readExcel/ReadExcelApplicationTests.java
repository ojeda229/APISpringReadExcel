package com.ojeda.readExcel;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ReadExcelApplicationTests {

	@Test
	void contextLoads() {
	}

}
